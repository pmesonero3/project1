//Philippe MESONERO

public interface EventHandler {
    void handle(Event event);

}
